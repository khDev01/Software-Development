﻿//        Date: 10/05/2019
//      Author: Kasim Hussain 
// Description: Tic Tac Toe player class

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kasim104016TicTacToe
{
    class Player
    {
        // private variables within the scope of the class
        private bool blnPlayerStatus;
        private SetMarker mkPlayermarker;

        public  Player(bool pPlayStatus, string pMark)
        {
            blnPlayerStatus = pPlayStatus;
            mkPlayermarker = new SetMarker(pMark);
        }

        //PlayerStatus property
        public bool PlayerStatus
        {
            get { return blnPlayerStatus; }
            set { blnPlayerStatus = value; }
        }

        //PlayerMarker property
        public string PlayerMarker
        {
            get { return mkPlayermarker.PlayerMarker; }
        }
    }
}
