﻿//        Date: 10/05/2019
//      Author: Kasim Hussain
// Description: Tic Tac Toe game

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kasim104016TicTacToe
{
    public partial class TTTgame : Form
    {
        //Properties
        private Boolean blnDraw;
        private Boolean blnPlayerX;
        private Boolean blnPlayerO;
        private Boolean blnGameOver;

        //Player class declarations
        Player PlayerX;
        Player PlayerO;

        public TTTgame()
        {
            InitializeComponent();
            ResetGame();
        }

        //Welcome message when form loads
        private void KasimGame_Load(object sender, EventArgs e)
        {
            string message = "Welcome to Kasim's Tic Tac Toe game";
            MessageBox.Show(message);
        }

        //create players
        public void CreatePlayers()
        {
            if (PlayerX == null)
            {
                PlayerX = new Player(true, "X");
            }
            if (PlayerO == null)
            {
                PlayerO = new Player(false, "O");
            }

        }

        //resets board and game state
        private void ResetGame()
        {
            //creat players
            CreatePlayers();

            //Clear the board 
            TopLeft.Text = "";
            TopLeft.BackColor = Color.White;
            TopCenter.Text = "";
            TopCenter.BackColor = Color.White;
            TopRight.Text = "";
            TopRight.BackColor = Color.White;
            CenterLeft.Text = "";
            CenterLeft.BackColor = Color.White;
            CenterCenter.Text = "";
            CenterCenter.BackColor = Color.White;
            CenterRight.Text = "";
            CenterRight.BackColor = Color.White;
            BottomLeft.Text = "";
            BottomLeft.BackColor = Color.White;
            BottomCenter.Text = "";
            BottomCenter.BackColor = Color.White;
            BottomRight.Text = "";
            BottomRight.BackColor = Color.White;
            lblMessage.Text = "";

            blnGameOver = false;
            blnDraw = false;
            blnPlayerX = false;
            blnPlayerO = false;
            labelTurn.Text = "Turn = X";
            PlayerX.PlayerStatus = true;
            PlayerO.PlayerStatus = false;
        }

        //Events for clicking buttons
        private void TopLeft_Click(object sender, EventArgs e)
        {
            Game_Click(TopLeft);
        }

        private void TopCenter_Click(object sender, EventArgs e)
        {
            Game_Click(TopCenter);
        }

        private void TopRight_Click(object sender, EventArgs e)
        {
            Game_Click(TopRight);
        }

        private void CenterLeft_Click(object sender, EventArgs e)
        {
            Game_Click(CenterLeft);
        }

        private void CenterCenter_Click(object sender, EventArgs e)
        {
            Game_Click(CenterCenter);
        }

        private void CenterRight_Click(object sender, EventArgs e)
        {
            Game_Click(CenterRight);
        }

        private void BottomLeft_Click(object sender, EventArgs e)
        {
            Game_Click(BottomLeft);
        }

        private void BottomCenter_Click(object sender, EventArgs e)
        {
            Game_Click(BottomCenter);
        }

        private void BottomRight_Click(object sender, EventArgs e)
        {
            Game_Click(BottomRight);
        }

        //Event handler for click event (all squares)
        void Game_Click(Button BoardSquare)
        {
            if (blnGameOver == false)
            {
                //Player X turn to pick a position
                if (PlayerX.PlayerStatus == true)
                {
                    if (BoardSquare.Text == "")
                    {
                        BoardSquare.Text = PlayerX.PlayerMarker;
                    }
                    else
                    {
                        lblMessage.Text = "The choice made wasn't empty";
                    }
                }

                //Player O turn to pick a position
                if (PlayerO.PlayerStatus == true)
                {
                    if (BoardSquare.Text == "")
                    {
                        BoardSquare.Text = PlayerO.PlayerMarker;
                    }
                    else
                    {
                        lblMessage.Text = "The choice made wasn't empty";
                    }
                }

                //Check if X has Won
                CheckXWinningLine();
                if (blnPlayerX == true)
                {
                    lblMessage.Text = "X Wins";
                    ScoreBoard();
                    blnGameOver = true;
                }

                //Check if O has Won
                CheckOWinningLine();
                if (blnPlayerO == true)
                {
                    lblMessage.Text = "O Wins";
                    ScoreBoard();
                    blnGameOver = true;
                }

                //Check for a draw
                CheckDraw();
                if (blnDraw == true)
                {
                    lblMessage.Text = "Game Drawn";
                    blnGameOver = true;
                }

                //Change turn of player
                if (PlayerO.PlayerStatus == true)
                {
                    labelTurn.Text = "Turn = X";
                    PlayerO.PlayerStatus = false;
                    PlayerX.PlayerStatus = true;
                }
                else
                {
                    labelTurn.Text = "Turn = O";
                    PlayerO.PlayerStatus = true;
                    PlayerX.PlayerStatus = false;
                }
            }
        }

        //Function to check for a draw
        private void CheckDraw()
        {
            int count = 1;

            if (TopLeft.Text != "")
            {
                count++;
            }
            if (TopCenter.Text != "")
            {
                count++;
            }

            if (TopRight.Text != "")
            {
                count++;
            }
            if (CenterLeft.Text != "")
            {
                count++;
            }
            if (CenterCenter.Text != "")
            {
                count++;
            }
            if (CenterRight.Text != "")
            {
                count++;
            }
            if (BottomLeft.Text != "")
            {
                count++;
            }
            if (BottomCenter.Text != "")
            {
                count++;
            }
            if (BottomRight.Text != "")
            {
                count++;
            }

            if (count == 9)
            {
                blnDraw = true;
            }
        }

        //Check for X winning line
        private void CheckXWinningLine()
        {
            //Check HORIZONTAL lines for winner  
            if (TopLeft.Text == "X" & TopCenter.Text == "X" & TopRight.Text == "X")
            {
                blnPlayerX = true;
            }
            if (CenterLeft.Text == "X" & CenterCenter.Text == "X" & CenterRight.Text == "X")
            {
                blnPlayerX = true;
            }
            if (BottomLeft.Text == "X" & BottomCenter.Text == "X" & BottomRight.Text == "X")
            {
                blnPlayerX = true;
            }

            // Check VERTICAL lines for winner  
            if (TopLeft.Text == "X" & CenterLeft.Text == "X" & BottomLeft.Text == "X")
            {
                blnPlayerX = true;
            }
            if (TopCenter.Text == "X" & CenterCenter.Text == "X" & BottomCenter.Text == "X")
            {
                blnPlayerX = true;
            }
            if (TopRight.Text == "X" & CenterRight.Text == "X" & BottomRight.Text == "X")
            {
                blnPlayerX = true;
            }

            //Check DIAGONAL lines for winner  
            if (TopLeft.Text == "X" & CenterCenter.Text == "X" & BottomRight.Text == "X")
            {
                blnPlayerX = true;
            }
            if (TopRight.Text == "X" & CenterCenter.Text == "X" & BottomLeft.Text == "X")
            {
                blnPlayerX = true;
            }
        }

        //Check for O winning line
        private void CheckOWinningLine()
        {
            //Check HORIZONTAL lines for winner  
            if (TopLeft.Text == "O" & TopCenter.Text == "O" & TopRight.Text == "O")
            {
                blnPlayerO = true;
            }
            if (CenterLeft.Text == "O" & CenterCenter.Text == "O" & CenterRight.Text == "O")
            {
                blnPlayerO = true;
            }
            if (BottomLeft.Text == "O" & BottomCenter.Text == "O" & BottomRight.Text == "O")
            {
                blnPlayerO = true;
            }

            // Check VERTICAL lines for winner  
            if (TopLeft.Text == "O" & CenterLeft.Text == "O" & BottomLeft.Text == "O")
            {
                blnPlayerO = true;
            }
            if (TopCenter.Text == "O" & CenterCenter.Text == "O" & BottomCenter.Text == "O")
            {
                blnPlayerO = true;
            }
            if (TopRight.Text == "O" & CenterRight.Text == "O" & BottomRight.Text == "O")
            {
                blnPlayerO = true;
            }
            //Check DIAGONAL lines for winner  
            if (TopLeft.Text == "O" & CenterCenter.Text == "O" & BottomRight.Text == "O")
            {
                blnPlayerO = true;
            }
            if (TopRight.Text == "O" & CenterCenter.Text == "O" & BottomLeft.Text == "O")
            {
                blnPlayerO = true;
            }
        }

        //Score board update function 
        private void ScoreBoard()
        {
            int Converter;

            if (PlayerX.PlayerStatus == true)
            {
                Converter = Convert.ToInt32(labelXScore.Text);
                Converter = Converter + 1;
                labelXScore.Text = Converter.ToString();
            }
            if (PlayerO.PlayerStatus == true)
            {
                Converter = Convert.ToInt32(labelOScore.Text);
                Converter = Converter + 1;
                labelOScore.Text = Converter.ToString();
            }
        }

        private void ResetGame_Click(object sender, EventArgs e)
        {
            ResetGame();
            lblMessage.Text = "Game Reset";
        }

        Help f2 = new Help();
       
        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        { 
            f2.Show();
        }
    }
}
