﻿namespace Kasim104016TicTacToe
{
    partial class TTTgame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TopLeft = new System.Windows.Forms.Button();
            this.TopCenter = new System.Windows.Forms.Button();
            this.TopRight = new System.Windows.Forms.Button();
            this.CenterLeft = new System.Windows.Forms.Button();
            this.CenterCenter = new System.Windows.Forms.Button();
            this.CenterRight = new System.Windows.Forms.Button();
            this.BottomLeft = new System.Windows.Forms.Button();
            this.BottomCenter = new System.Windows.Forms.Button();
            this.BottomRight = new System.Windows.Forms.Button();
            this.btnResetGame = new System.Windows.Forms.Button();
            this.labelTurn = new System.Windows.Forms.Label();
            this.labelOScore = new System.Windows.Forms.Label();
            this.labelO = new System.Windows.Forms.Label();
            this.labelXScore = new System.Windows.Forms.Label();
            this.labelX = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TopLeft
            // 
            this.TopLeft.BackColor = System.Drawing.Color.White;
            this.TopLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TopLeft.Location = new System.Drawing.Point(48, 49);
            this.TopLeft.Name = "TopLeft";
            this.TopLeft.Size = new System.Drawing.Size(100, 100);
            this.TopLeft.TabIndex = 23;
            this.TopLeft.UseVisualStyleBackColor = false;
            this.TopLeft.Click += new System.EventHandler(this.TopLeft_Click);
            // 
            // TopCenter
            // 
            this.TopCenter.BackColor = System.Drawing.Color.White;
            this.TopCenter.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TopCenter.Location = new System.Drawing.Point(154, 49);
            this.TopCenter.Name = "TopCenter";
            this.TopCenter.Size = new System.Drawing.Size(100, 100);
            this.TopCenter.TabIndex = 24;
            this.TopCenter.UseVisualStyleBackColor = false;
            this.TopCenter.Click += new System.EventHandler(this.TopCenter_Click);
            // 
            // TopRight
            // 
            this.TopRight.BackColor = System.Drawing.Color.White;
            this.TopRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TopRight.Location = new System.Drawing.Point(260, 49);
            this.TopRight.Name = "TopRight";
            this.TopRight.Size = new System.Drawing.Size(100, 100);
            this.TopRight.TabIndex = 25;
            this.TopRight.UseVisualStyleBackColor = false;
            this.TopRight.Click += new System.EventHandler(this.TopRight_Click);
            // 
            // CenterLeft
            // 
            this.CenterLeft.BackColor = System.Drawing.Color.White;
            this.CenterLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CenterLeft.Location = new System.Drawing.Point(48, 155);
            this.CenterLeft.Name = "CenterLeft";
            this.CenterLeft.Size = new System.Drawing.Size(100, 100);
            this.CenterLeft.TabIndex = 26;
            this.CenterLeft.UseVisualStyleBackColor = false;
            this.CenterLeft.Click += new System.EventHandler(this.CenterLeft_Click);
            // 
            // CenterCenter
            // 
            this.CenterCenter.BackColor = System.Drawing.Color.White;
            this.CenterCenter.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CenterCenter.Location = new System.Drawing.Point(154, 155);
            this.CenterCenter.Name = "CenterCenter";
            this.CenterCenter.Size = new System.Drawing.Size(100, 100);
            this.CenterCenter.TabIndex = 27;
            this.CenterCenter.UseVisualStyleBackColor = false;
            this.CenterCenter.Click += new System.EventHandler(this.CenterCenter_Click);
            // 
            // CenterRight
            // 
            this.CenterRight.BackColor = System.Drawing.Color.White;
            this.CenterRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CenterRight.Location = new System.Drawing.Point(260, 155);
            this.CenterRight.Name = "CenterRight";
            this.CenterRight.Size = new System.Drawing.Size(100, 100);
            this.CenterRight.TabIndex = 28;
            this.CenterRight.UseVisualStyleBackColor = false;
            this.CenterRight.Click += new System.EventHandler(this.CenterRight_Click);
            // 
            // BottomLeft
            // 
            this.BottomLeft.BackColor = System.Drawing.Color.White;
            this.BottomLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BottomLeft.Location = new System.Drawing.Point(48, 261);
            this.BottomLeft.Name = "BottomLeft";
            this.BottomLeft.Size = new System.Drawing.Size(100, 100);
            this.BottomLeft.TabIndex = 29;
            this.BottomLeft.UseVisualStyleBackColor = false;
            this.BottomLeft.Click += new System.EventHandler(this.BottomLeft_Click);
            // 
            // BottomCenter
            // 
            this.BottomCenter.BackColor = System.Drawing.Color.White;
            this.BottomCenter.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BottomCenter.Location = new System.Drawing.Point(154, 261);
            this.BottomCenter.Name = "BottomCenter";
            this.BottomCenter.Size = new System.Drawing.Size(100, 100);
            this.BottomCenter.TabIndex = 30;
            this.BottomCenter.UseVisualStyleBackColor = false;
            this.BottomCenter.Click += new System.EventHandler(this.BottomCenter_Click);
            // 
            // BottomRight
            // 
            this.BottomRight.BackColor = System.Drawing.Color.White;
            this.BottomRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BottomRight.Location = new System.Drawing.Point(260, 261);
            this.BottomRight.Name = "BottomRight";
            this.BottomRight.Size = new System.Drawing.Size(100, 100);
            this.BottomRight.TabIndex = 31;
            this.BottomRight.UseVisualStyleBackColor = false;
            this.BottomRight.Click += new System.EventHandler(this.BottomRight_Click);
            // 
            // btnResetGame
            // 
            this.btnResetGame.BackColor = System.Drawing.Color.White;
            this.btnResetGame.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetGame.Location = new System.Drawing.Point(390, 285);
            this.btnResetGame.Name = "btnResetGame";
            this.btnResetGame.Size = new System.Drawing.Size(100, 45);
            this.btnResetGame.TabIndex = 32;
            this.btnResetGame.Text = "Reset";
            this.btnResetGame.UseVisualStyleBackColor = false;
            this.btnResetGame.Click += new System.EventHandler(this.ResetGame_Click);
            // 
            // labelTurn
            // 
            this.labelTurn.AutoSize = true;
            this.labelTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTurn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelTurn.Location = new System.Drawing.Point(172, 368);
            this.labelTurn.Name = "labelTurn";
            this.labelTurn.Size = new System.Drawing.Size(63, 17);
            this.labelTurn.TabIndex = 37;
            this.labelTurn.Text = "Turn = X";
            // 
            // labelOScore
            // 
            this.labelOScore.AutoSize = true;
            this.labelOScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOScore.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelOScore.Location = new System.Drawing.Point(445, 149);
            this.labelOScore.Name = "labelOScore";
            this.labelOScore.Size = new System.Drawing.Size(17, 17);
            this.labelOScore.TabIndex = 36;
            this.labelOScore.Text = "0";
            // 
            // labelO
            // 
            this.labelO.AutoSize = true;
            this.labelO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelO.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelO.Location = new System.Drawing.Point(408, 149);
            this.labelO.Name = "labelO";
            this.labelO.Size = new System.Drawing.Size(31, 17);
            this.labelO.TabIndex = 35;
            this.labelO.Text = "O =";
            // 
            // labelXScore
            // 
            this.labelXScore.AutoSize = true;
            this.labelXScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelXScore.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelXScore.Location = new System.Drawing.Point(445, 112);
            this.labelXScore.Name = "labelXScore";
            this.labelXScore.Size = new System.Drawing.Size(17, 17);
            this.labelXScore.TabIndex = 34;
            this.labelXScore.Text = "0";
            // 
            // labelX
            // 
            this.labelX.AutoSize = true;
            this.labelX.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelX.Location = new System.Drawing.Point(410, 112);
            this.labelX.Name = "labelX";
            this.labelX.Size = new System.Drawing.Size(29, 17);
            this.labelX.TabIndex = 33;
            this.labelX.Text = "X =";
            // 
            // lblMessage
            // 
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(394, 249);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(96, 22);
            this.lblMessage.TabIndex = 38;
            this.lblMessage.Text = "Info label";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(403, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 39;
            this.label1.Text = "SCORE:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(524, 24);
            this.menuStrip1.TabIndex = 40;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // TTTgame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(524, 401);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.labelTurn);
            this.Controls.Add(this.labelOScore);
            this.Controls.Add(this.labelO);
            this.Controls.Add(this.labelXScore);
            this.Controls.Add(this.labelX);
            this.Controls.Add(this.btnResetGame);
            this.Controls.Add(this.BottomRight);
            this.Controls.Add(this.BottomCenter);
            this.Controls.Add(this.BottomLeft);
            this.Controls.Add(this.CenterRight);
            this.Controls.Add(this.CenterCenter);
            this.Controls.Add(this.CenterLeft);
            this.Controls.Add(this.TopRight);
            this.Controls.Add(this.TopCenter);
            this.Controls.Add(this.TopLeft);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "TTTgame";
            this.Text = "Kasim Tic Tac Toe Game";
            this.Load += new System.EventHandler(this.KasimGame_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button TopLeft;
        private System.Windows.Forms.Button TopCenter;
        private System.Windows.Forms.Button TopRight;
        private System.Windows.Forms.Button CenterLeft;
        private System.Windows.Forms.Button CenterCenter;
        private System.Windows.Forms.Button CenterRight;
        private System.Windows.Forms.Button BottomLeft;
        private System.Windows.Forms.Button BottomCenter;
        private System.Windows.Forms.Button BottomRight;
        private System.Windows.Forms.Button btnResetGame;
        private System.Windows.Forms.Label labelTurn;
        private System.Windows.Forms.Label labelOScore;
        private System.Windows.Forms.Label labelO;
        private System.Windows.Forms.Label labelXScore;
        private System.Windows.Forms.Label labelX;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
    }
}

