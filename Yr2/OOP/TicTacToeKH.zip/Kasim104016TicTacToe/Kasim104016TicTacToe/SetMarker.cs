﻿//        Date: 10/05/2019
//      Author: Kasim Hussain 
// Description: Tic Tac Toe Marker class

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kasim104016TicTacToe
{
    class SetMarker
    {
        private string strMarker;

        //Constructor
        public SetMarker(string pMarker)
        {
            strMarker = pMarker;
        }

        //PlayerMarker property
        public string PlayerMarker
        {
            get { return strMarker; }
            set { strMarker = value; }
        }
    }
}
